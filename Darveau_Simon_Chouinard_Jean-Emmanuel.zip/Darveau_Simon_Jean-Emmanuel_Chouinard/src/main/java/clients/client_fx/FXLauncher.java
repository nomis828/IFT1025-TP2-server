package clients.client_fx;

/**
 Permet de lancer le controlleur, la vue et le modèle
 */
public class FXLauncher {
    public static void main(String[] args) {
        View.main(args);
    }
}
